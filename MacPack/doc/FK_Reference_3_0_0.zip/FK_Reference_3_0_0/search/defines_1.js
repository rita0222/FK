var searchData=
[
  ['cl_5fuse_5fdeprecated_5fopencl_5f2_5f0_5fapis',['CL_USE_DEPRECATED_OPENCL_2_0_APIS',['../OpenCL_8h.html#a83e58027079a192080c2690ec9918612',1,'OpenCL.h']]]
];
