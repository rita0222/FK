var searchData=
[
  ['ov_5fexclude_5fstatic_5fcallbacks',['OV_EXCLUDE_STATIC_CALLBACKS',['../Audio_8h.html#a2a60377a2e2638ce01f396b8fc6ac73a',1,'Audio.h']]]
];
