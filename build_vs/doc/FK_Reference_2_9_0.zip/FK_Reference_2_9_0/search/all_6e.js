var searchData=
[
  ['negate',['negate',['../classfk__GenMatrix.html#a54dc3c91a8ac9edd3a34e5e41d7ef8b0',1,'fk_GenMatrix::negate()'],['../classfk__OrthoMatrix.html#a76be9a00b4a5053042df45fc1e7e80a3',1,'fk_OrthoMatrix::negate()']]],
  ['negatebody',['negateBody',['../classfk__Operation.html#a4123b4ab4ac9b7a8373d739643f01f35',1,'fk_Operation']]],
  ['newimage',['newImage',['../classfk__Image.html#a6d2dc3852b695cd0ea279b95230944a7',1,'fk_Image']]],
  ['newparticle',['newParticle',['../classfk__ParticleSet.html#af7db49e51e35d4e0853c2d9248857e9e',1,'fk_ParticleSet::newParticle(void)'],['../classfk__ParticleSet.html#ae9acc9f88b69aaf0d9952ddabad9377f',1,'fk_ParticleSet::newParticle(const fk_Vector &amp;pos)'],['../classfk__ParticleSet.html#adce002eb31a9e9f1e37c5ac4b78ac985',1,'fk_ParticleSet::newParticle(double x, double y, double z)']]],
  ['nextframe',['nextFrame',['../classfk__BVHMotion.html#af0af8bbeeaad040460927a2bf0ebce55',1,'fk_BVHMotion']]],
  ['norm',['norm',['../classfk__GenVector.html#aecc360c5bc4f5ed7c45260d6513ac696',1,'fk_GenVector::norm()'],['../classfk__Quaternion.html#a6eb16d1954b63534bad9c15c8d8efa5e',1,'fk_Quaternion::norm()'],['../classfk__Surface.html#aa5acccd25e2c6ab9c90e959bca2ddb6f',1,'fk_Surface::norm()']]],
  ['norm2',['norm2',['../classfk__GenVector.html#a85a29d3755e8ada322a4ccbd4da1beae',1,'fk_GenVector']]],
  ['normalize',['normalize',['../classfk__Complex.html#a74537cb5613c1b50cfcd58ae5251f1cc',1,'fk_Complex::normalize()'],['../classfk__GenVector.html#af49108813471c7afef13f48666102e72',1,'fk_GenVector::normalize()'],['../classfk__Quaternion.html#ad55f177b49b10dd77dcd1a7afe058ba4',1,'fk_Quaternion::normalize()'],['../classfk__Vector.html#a15229579b055c97eee5516940b38bb5a',1,'fk_Vector::normalize()']]]
];
