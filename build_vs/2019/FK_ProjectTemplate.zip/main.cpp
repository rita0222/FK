﻿#include <FK/FK.h>

using namespace FK;
using namespace FK::Material;

int main(int, char *[])
{
	fk_AppWindow	window;
	fk_Model		blockModel;
	fk_Block		block(50.0, 70.0, 40.0);

	// マテリアルの初期化
	fk_Material::initDefault();

	// ウィンドウ設定
	window.setSize(800, 800);

	// 直方体の設定
	blockModel.setShape(&block);
	blockModel.setMaterial(Yellow);

	window.setCameraPos(0.0, 0.0, 500.0);
	window.setCameraFocus(0.0, 0.0, 0.0);

	// 各モデルをウィンドウに登録
	window.entry(&blockModel);
	window.open();

	while(window.update() == true) {
		blockModel.loRotateWithVec(0.0, 0.0, 0.0, fk_Y, FK_PI / 1000.0);
	}

	return 0;
}
